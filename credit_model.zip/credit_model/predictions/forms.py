from django import forms


class PredictionForm(forms.Form):
    age = forms.IntegerField(label="Age")
    employment_length = forms.IntegerField(label="Employment Length (in years)")
    home_ownership = forms.ChoiceField(choices=[
        ('RENT', 'Rent'),
        ('OWN', 'Own'),
        ('MORTGAGE', 'Mortgage'),
        ('OTHER', 'Other')  # Added for completeness
    ], label="Home Ownership")

    loan_intent = forms.ChoiceField(choices=[
        ('EDUCATION', 'Education'),
        ('MEDICAL', 'Medical'),
        ('VENTURE', 'Venture'),
        ('DEBTCONSOLIDATION', 'Debt Consolidation'),  # Added for completeness
        ('HOMEIMPROVEMENT', 'Home Improvement'),  # Added for completeness
        ('PERSONAL', 'Personal'),  # Added for completeness
    ], label="Loan Intent")

    loan_amount = forms.IntegerField(label="Loan Amount")
    income = forms.IntegerField(label="Annual Income")

    loan_grade = forms.ChoiceField(choices=[
        ('A', 'A'),
        ('B', 'B'),
        ('C', 'C'),
        ('D', 'D'),
        ('E', 'E'),
        ('F', 'F'),
        ('G', 'G'),
    ], label="Loan Grade")

    loan_int_rate = forms.FloatField(label="Loan Interest Rate")
    loan_percent_income = forms.FloatField(label="Loan Percent Income")

    cb_person_default_on_file = forms.ChoiceField(choices=[
        ('Y', 'Yes'),
        ('N', 'No')
    ], label="Credit Bureau Person Default on File")

    cb_person_cred_hist_length = forms.IntegerField(label="Credit History Length (In Years)")
