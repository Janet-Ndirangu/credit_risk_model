from django.shortcuts import render
from django.http import JsonResponse
from .forms import PredictionForm
from catboost import CatBoostClassifier
import numpy as np
import pandas as pd
import joblib

# Load the CatBoost model and scaler
model_path = 'predictions/models/catboost_model.cbm'
scaler_path = 'predictions/models/scaler.pkl'
catboost_model = CatBoostClassifier()
catboost_model.load_model(model_path)
scaler = joblib.load(scaler_path)

# Prediction view
def predict(request):
    if request.method == 'POST':
        form = PredictionForm(request.POST)
        if form.is_valid():
            # Extract data from form
            person_age = form.cleaned_data['age']
            person_income = form.cleaned_data['income']
            person_home_ownership = form.cleaned_data['home_ownership']
            person_emp_length = form.cleaned_data['employment_length']
            loan_intent = form.cleaned_data['loan_intent']
            loan_amnt = form.cleaned_data['loan_amount']
            loan_grade = form.cleaned_data['loan_grade']
            loan_int_rate = form.cleaned_data['loan_int_rate']
            loan_percent_income = form.cleaned_data['loan_percent_income']
            cb_person_default_on_file = form.cleaned_data['cb_person_default_on_file']
            cb_person_cred_hist_length = form.cleaned_data['cb_person_cred_hist_length']

            # Prepare a DataFrame for one-hot encoding
            input_df = pd.DataFrame({
                'person_age': [person_age],
                'person_income': [person_income],
                'person_emp_length': [person_emp_length],
                'loan_amnt': [loan_amnt],
                'loan_int_rate': [loan_int_rate],
                'loan_percent_income': [loan_percent_income],
                'cb_person_cred_hist_length': [cb_person_cred_hist_length],
                'person_home_ownership': [person_home_ownership],
                'loan_intent': [loan_intent],
                'loan_grade': [loan_grade],
                'cb_person_default_on_file': [cb_person_default_on_file]
            })

            # One-hot encode the categorical features
            input_df_encoded = pd.get_dummies(input_df, columns=['person_home_ownership', 'loan_intent', 'loan_grade', 'cb_person_default_on_file'], drop_first=True)

            # Expected columns for prediction
            expected_columns = ['person_age', 'person_income', 'person_emp_length', 'loan_amnt',
                                'loan_int_rate', 'loan_percent_income', 'cb_person_cred_hist_length',
                                'person_home_ownership_MORTGAGE', 'person_home_ownership_OTHER',
                                'person_home_ownership_OWN', 'person_home_ownership_RENT',
                                'loan_intent_DEBTCONSOLIDATION', 'loan_intent_EDUCATION',
                                'loan_intent_HOMEIMPROVEMENT', 'loan_intent_MEDICAL',
                                'loan_intent_PERSONAL', 'loan_intent_VENTURE',
                                'loan_grade_A', 'loan_grade_B', 'loan_grade_C', 'loan_grade_D',
                                'loan_grade_E', 'loan_grade_F', 'loan_grade_G',
                                'cb_person_default_on_file_Y', 'cb_person_default_on_file_N']

            # Ensure the input data has the same columns as the model was trained on
            for col in expected_columns:
                if col not in input_df_encoded.columns:
                    input_df_encoded[col] = 0  # Fill missing columns with zeros

            # Prepare input data in the correct order
            input_data = input_df_encoded[expected_columns].values

            # Scale the input data
            input_data_scaled = scaler.transform(input_data)

            # Make prediction
            prediction = catboost_model.predict(input_data_scaled)

            # Map prediction to meaningful labels
            result = "Highly likely to Default" if prediction[0] == 1 else "Not likely to Default"

            return JsonResponse({'prediction': result})
    else:
        form = PredictionForm()

    return render(request, 'predictions/predict.html', {'form': form})
